/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalsystem;

public class HospitalInformation {

    @Override
    public String toString() {
        return "\nAbout Us:\n "
                + "\nDr. Sulaiman Al Habib Medical Services Group Company (HMG) is a diversified healthcare and solutions leader in the Middle East, \nrecognized for comprehensive healthcare services, forwardthinking innovation and the superior patient experience in the region.\n"
                + "\nOur Vision:\nTo be the most trusted healthcare provider in medical excellence and patient experience globally.\n"
                + "\nLocation:\nKing Fahad Road - Olaya - Riyadh"
                + "\nKhurais Road, Riyadh"
                + "\nTakhassusi Road - Rahmaniya - Riyadh";
    }
    
    
    
}
